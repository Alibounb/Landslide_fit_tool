PyQt is a set of Python v2 and v3 bindings for Digia's Qt application framework


